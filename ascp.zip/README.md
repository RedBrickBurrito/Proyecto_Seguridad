Para correr el programa `node ascp_json.js 2021`
